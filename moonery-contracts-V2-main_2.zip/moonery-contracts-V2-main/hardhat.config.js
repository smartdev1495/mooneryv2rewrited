/// ENVVAR
// - ENABLE_GAS_REPORT
// - CI
// - COMPILE_MODE
require('dotenv').config();

const fs = require('fs');
const path = require('path');
const argv = require('yargs/yargs')()
  .env('')
  .boolean('enableGasReport')
  .boolean('ci')
  .string('compileMode')
  .argv;

require('@nomiclabs/hardhat-truffle5');
require('@nomiclabs/hardhat-solhint');
require('solidity-coverage');
require('@nomiclabs/hardhat-waffle');
require('@nomiclabs/hardhat-ethers');
require("@nomiclabs/hardhat-etherscan");
require('hardhat-contract-sizer');

if (argv.enableGasReport) {
  require('hardhat-gas-reporter');
}

for (const f of fs.readdirSync(path.join(__dirname, 'hardhat'))) {
  require(path.join(__dirname, 'hardhat', f));
}

/**
 * @type import('hardhat/config').HardhatUserConfig
 */
module.exports = {
  solidity: {
    version: '0.8.3',
    settings: {
      optimizer: {
        enabled: true,
        runs: 2000,
      },
    },
  },
  networks: {
    hardhat: {
      forking: {
        url: 'https://bsc-dataseed.binance.org',
        method: "hardhat_reset",
      },
      allowUnlimitedContractSize: true
    },
    testnet: {
      url: 'https://data-seed-prebsc-1-s1.binance.org:8545',
      "accounts": {
        "mnemonic": process.env.MNEMONIC,
      },
      allowUnlimitedContractSize: true,
      gas: "auto"
    },
    mainnet: {
      url: 'https://bsc-dataseed.binance.org/',
      "accounts": {
        "mnemonic": process.env.MNEMONIC,
      },
      allowUnlimitedContractSize: true,
      gas: "auto",
      confirmations: 10,
    },
  },
  gasReporter: {
    currency: 'USD',
    outputFile: argv.ci ? 'gas-report.txt' : undefined,
  },
  paths: {
    sources: "./contracts",
    tests: "./test",
    cache: "./cache",
    artifacts: "./artifacts",
    buildinfo: "./artifacts/build-info"
  },
  etherscan: {
    apiKey: process.env.BSCAPIKEY
  },
  contractSizer: {
    alphaSort: true,
    runOnCompile: true,
    disambiguatePaths: false,
  }
};