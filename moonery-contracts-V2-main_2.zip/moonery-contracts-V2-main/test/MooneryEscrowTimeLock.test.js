const { BN, constants, expectRevert, time } = require('@openzeppelin/test-helpers');

const { ZERO_ADDRESS } = constants;

const { expect } = require('chai');

const ERC20Mock = artifacts.require('ERC20Mock');
const MooneryEscrowTimeLock = artifacts.require('MooneryEscrowTimeLock');

contract('MooneryEscrowTimeLock', function (accounts) {
  const [ deployer, beneficiary ] = accounts;

  const name = 'My Token';
  const symbol = 'MTKN';

  const amount = new BN(100);
  const zeroBalance = new BN(0);

  context('with token', function () {
    beforeEach(async function () {
      this.token = await ERC20Mock.new(name, symbol, deployer, 0, { from: deployer }); // We're not using the preminted tokens
      await this.token.mint(deployer, amount);
    });

    it('should have token balance deployer', async function () {
      expect(
        await this.token.balanceOf(deployer))
        .to.be.bignumber.equal(amount);
    });

    context('once deployed', async function () {
      beforeEach(async function () {
        this.tokenEscrow = await MooneryEscrowTimeLock.new({ from: deployer });
      });

      it('should start with 0 releaseTime', async function () {
        expect(await this.tokenEscrow.releaseTime()).to.be.bignumber.equal(zeroBalance);
      });

      it('should open', async function () {
        expect(await this.tokenEscrow.isOpen()).to.equal(true);
      });

      it('should have 0 balance', async function () {
        expect(await this.token.balanceOf(this.tokenEscrow.address)).to.be.bignumber.equal(zeroBalance);
      });

      it('reverts 0 balance', async function () {
        await expectRevert(
          this.tokenEscrow.fallbackRedeem(this.token.address, deployer, amount, { from: deployer }),
          'ERC20Fallback: no token to release',
        );
      });

      context('fallbackRedeem', async function () {
        describe('deposit tokens', function () {
          beforeEach(async function () {
            await this.token.transfer(this.tokenEscrow.address, amount, { from: deployer });
          });

          it('should have 0 token balance beneficiary', async function () {
            expect(
              await this.tokenEscrow.tokenBalanceOf(this.token.address, beneficiary))
              .to.be.bignumber.equal(zeroBalance);
          });

          it('reverts zero token address', async function () {
            await expectRevert(
              this.tokenEscrow.fallbackRedeem(ZERO_ADDRESS, deployer, amount, { from: deployer }),
              'ERC20Fallback: token is the zero address',
            );
          });

          it('reverts zero beneficiary address', async function () {
            await expectRevert(
              this.tokenEscrow.fallbackRedeem(this.token.address, ZERO_ADDRESS, amount, { from: deployer }),
              'ERC20Fallback: cannot recover to zero address',
            );
          });

          it('reverts 0 amount', async function () {
            await expectRevert(
              this.tokenEscrow.fallbackRedeem(this.token.address, deployer, zeroBalance, { from: deployer }),
              'ERC20Fallback: amount is 0',
            );
          });

          it('reverts not admin', async function () {
            await expectRevert(
              this.tokenEscrow.fallbackRedeem(this.token.address, beneficiary, amount, { from: beneficiary }),
              'MooneryEscrowTimeLock: caller is not an admin',
            );
          });

          it('should reduce token balance after fallbackRedeem token', async function () {
            expect(await this.token.balanceOf(this.tokenEscrow.address)).to.be.bignumber.equal(amount);
            await this.tokenEscrow.fallbackRedeem(this.token.address, deployer, amount, { from: deployer });
            expect(await this.token.balanceOf(this.tokenEscrow.address)).to.be.bignumber.equal(zeroBalance);
          });

          context('lock', async function () {
            describe('lock time', function () {
              beforeEach(async function () {
                const futureReleaseTime = (await time.latest()).add(time.duration.years(1));
                await this.tokenEscrow.lock(futureReleaseTime, { from: deployer });
              });

              it('reverts on lock', async function () {
                await expectRevert(
                  this.tokenEscrow.fallbackRedeem(this.token.address, deployer, amount, { from: deployer }),
                  'MooneryEscrowTimeLock: not open',
                );
              });
            });
          });
        });
      });

      context('withdraw', async function () {
        describe('tokenDeposit', function () {
          beforeEach(async function () {
            await this.token.mint(beneficiary, amount);
          });

          it('reverts zero token address', async function () {
            await expectRevert(
              this.tokenEscrow.tokenDeposit(ZERO_ADDRESS, beneficiary, amount, { from: beneficiary }),
              'TokenEscrow: token is the zero address',
            );
          });

          it('reverts zero payee address', async function () {
            await expectRevert(
              this.tokenEscrow.tokenDeposit(this.token.address, ZERO_ADDRESS, amount, { from: beneficiary }),
              'TokenEscrow: payee_ is the zero address',
            );
          });

          it('reverts zero amount', async function () {
            await expectRevert(
              this.tokenEscrow.tokenDeposit(this.token.address, beneficiary, zeroBalance, { from: beneficiary }),
              'TokenEscrow: amount is 0',
            );
          });

          beforeEach(async function () {
            await this.token.approve(this.tokenEscrow.address, amount, { from: beneficiary });
            await this.tokenEscrow.tokenDeposit(this.token.address, beneficiary, amount, { from: beneficiary });
          });

          describe('tokenWithdraw', function () {
            it('reverts zero token address', async function () {
              await expectRevert(
                this.tokenEscrow.tokenWithdraw(ZERO_ADDRESS, beneficiary, amount, { from: beneficiary }),
                'TokenEscrow: token is the zero address',
              );
            });

            it('reverts zero beneficiary address', async function () {
              await expectRevert(
                this.tokenEscrow.tokenWithdraw(this.token.address, ZERO_ADDRESS, amount, { from: beneficiary }),
                'TokenEscrow: beneficiary is the zero address',
              );
            });

            it('reverts zero amount', async function () {
              await expectRevert(
                this.tokenEscrow.tokenWithdraw(this.token.address, beneficiary, zeroBalance, { from: beneficiary }),
                'TokenEscrow: amount is 0',
              );
            });

            it('should reduce token balance after withdraw token', async function () {
              expect(await this.token.balanceOf(this.tokenEscrow.address)).to.be.bignumber.equal(amount);
              expect(await this.token.balanceOf(beneficiary)).to.be.bignumber.equal(zeroBalance);
              await this.tokenEscrow.tokenWithdraw(this.token.address, beneficiary, amount, { from: beneficiary });
              expect(await this.token.balanceOf(this.tokenEscrow.address)).to.be.bignumber.equal(zeroBalance);
              expect(await this.token.balanceOf(beneficiary)).to.be.bignumber.equal(amount);
            });

            context('lock', async function () {
              describe('lock time', function () {
                beforeEach(async function () {
                  const futureReleaseTime = (await time.latest()).add(time.duration.years(1));
                  await this.tokenEscrow.lock(futureReleaseTime, { from: deployer });
                });
  
                it('reverts on lock', async function () {
                  await expectRevert(
                    this.tokenEscrow.tokenWithdraw(this.token.address, deployer, amount, { from: deployer }),
                    'MooneryEscrowTimeLock: not open',
                  );
                });

                describe('increase time', function () {
                  beforeEach(async function () {
                    await time.increaseTo((await time.latest()).add(time.duration.years(1)));
                  });

                  it('should reduce token balance after withdraw token', async function () {
                    expect(await this.token.balanceOf(this.tokenEscrow.address)).to.be.bignumber.equal(amount);
                    expect(await this.token.balanceOf(beneficiary)).to.be.bignumber.equal(zeroBalance);
                    await this.tokenEscrow.tokenWithdraw(this.token.address, beneficiary, amount, { from: beneficiary });
                    expect(await this.token.balanceOf(this.tokenEscrow.address)).to.be.bignumber.equal(zeroBalance);
                    expect(await this.token.balanceOf(beneficiary)).to.be.bignumber.equal(amount);
                  });

                  it('reverts withdraw twice', async function () {
                    await this.tokenEscrow.tokenWithdraw(this.token.address, beneficiary, amount, { from: beneficiary });
                    await expectRevert(
                      this.tokenEscrow.tokenWithdraw(this.token.address, beneficiary, amount, { from: beneficiary }),
                      'TokenEscrow: no tokens to release',
                    );
                  });
                });
              });
            });
          });
        });
      });
    });
  })
});
