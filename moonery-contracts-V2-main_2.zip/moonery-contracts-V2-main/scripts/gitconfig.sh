git config --global user.name "moonery-dev"
git config --global user.email "dev@moonery.io"
git config --local user.name "moonery-dev"
git config --local user.email "dev@moonery.io"